# Virginia's PiDog AI Robotics Project

An educational Raspberry Pi robot-dog showcase featuring movement demonstrations, spoken interaction, music playback, and a rescue-assistance concept.

> **Hardware note:** This repository is a starter project for the SunFounder PiDog. Test on a clear, level surface, keep the robot away from stairs and edges, and supervise every movement. Some action names and optional hardware features can vary by PiDog library version. Confirm them against the documentation for your installed version before the live demonstration.

## Project showcase

The planned showcase is organized into eight levels:

1. **Meet PiDog** – introduce the robot and explain what it is designed to demonstrate.
2. **Christmas Show** – play a Christmas audio file and perform a short movement routine.
3. **Pokémon Show** – present a themed performance using movement and spoken introductions.
4. **Human Interaction** – accept simple typed or optional voice commands and respond.
5. **Talent Show** – demonstrate tricks such as sit, walk, dance, bark, push-ups, handshake, high-five, and jump (only where supported by the installed PiDog library).
6. **Music and Dance** – play a selected audio file while PiDog performs a routine.
7. **Rescue Assistant Concept** – explain how a robot could support search-and-rescue teams by communicating, recognizing a person, and helping signal a location. This is a concept demonstration, not a certified rescue system.
8. **Finale** – thank the audience and perform a closing routine.

Only demonstrate features that your team has implemented and tested. Camera-based recognition, GPS/location reporting, and autonomous wilderness search are not implemented by this starter template.

## Repository layout

```text
Virginia-PiDog-AI-Robotics-Project/
├── app.py
├── pidog_controller.py
├── requirements.txt
├── README.md
├── commands/
│   ├── __init__.py
│   └── tricks.py
├── speech/
│   ├── __init__.py
│   └── voice_commands.py
├── music/
│   ├── __init__.py
│   └── player.py
├── interaction/
│   ├── __init__.py
│   └── rescue_purpose.py
└── assets/
    └── music/
        └── PUT_AUDIO_FILES_HERE.txt
```

## Requirements

- Raspberry Pi with Raspberry Pi OS
- SunFounder PiDog assembled and calibrated
- Python 3
- SunFounder `pidog` and `robot-hat` libraries installed using the official instructions
- Optional: `SpeechRecognition` and `PyAudio` for microphone input
- Optional: `pygame` for music playback

Install the optional Python packages:

```bash
python3 -m pip install -r requirements.txt
```

Install the PiDog libraries by following the official SunFounder PiDog documentation:
https://docs.sunfounder.com/projects/pidog/en/latest/

## Run

On the Raspberry Pi, open a terminal in this folder:

```bash
python3 app.py
```

To test the menu without connecting a PiDog, use:

```bash
python3 app.py --demo
```

The demo mode prints the actions instead of moving hardware.

## Add music

Place audio files such as `christmas_carol.mp3` or `show_music.mp3` inside `assets/music/`. Then choose the music option in the program. Use audio that your team has permission to play.

## Voice commands

Voice input is optional. Install and configure a microphone and the `SpeechRecognition`/`PyAudio` dependencies first. If microphone input is unavailable, use the typed-command option.

## Safety and limitations

- Keep hands, hair, cables, and objects clear of moving joints.
- Start with the robot on the floor and test one movement at a time.
- Keep the robot away from tables, stairs, and crowded areas.
- Do not balance objects on the robot's nose or body during movement.
- Speech responses are demonstrations, not medical or emergency advice.
- The rescue-assistance section describes a possible use case. It does not claim that this project can independently locate or rescue missing people.

## Team contribution notes

Update this section with each team member's actual contributions before submitting:

- PiDog assembly, calibration, and hardware setup
- Python programming and movement-command testing
- Speech and interactive responses
- Music and performance routines
- Documentation, testing, and presentation

## Project status

This is a structured starter repository. Review and test the action names against the installed PiDog library and add your team's final code, photos, and demonstration videos before publishing.
