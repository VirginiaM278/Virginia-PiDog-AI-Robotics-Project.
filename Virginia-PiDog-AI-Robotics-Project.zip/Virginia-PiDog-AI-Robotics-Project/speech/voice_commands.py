"""Typed commands always work; microphone recognition is optional."""

def listen_once():
    try:
        import speech_recognition as sr
    except ImportError:
        print("Voice recognition is not installed. Use typed commands instead.")
        return None

    recognizer = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            print("Listening... say a command.")
            recognizer.adjust_for_ambient_noise(source, duration=0.5)
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=5)
        return recognizer.recognize_google(audio).lower()
    except Exception as exc:
        print(f"Could not recognize speech: {exc}")
        return None
