"""Virginia's PiDog AI Robotics Project - interactive showcase menu."""
import argparse
from commands.tricks import TRICKS, dance, walk, sit, bark, pushups, jump
from pidog_controller import PiDogController
from interaction.rescue_purpose import explain_rescue_purpose
from music.player import list_tracks, play_track
from speech.voice_commands import listen_once

def show_intro(controller):
    controller.speak(
        "Welcome to our PiDog show! I am an educational robotic dog. "
        "I can demonstrate movement, music, and human interaction."
    )

def christmas_show(controller):
    controller.speak("Welcome to the Christmas show!")
    tracks = [p for p in list_tracks() if "christmas" in p.name.lower()]
    if tracks:
        # Music plays independently; stop it with Enter when prompted.
        play_track(tracks[0])
    else:
        print("Add a Christmas audio file to assets/music to play it.")
    dance(controller)
    sit(controller)

def pokemon_show(controller):
    controller.speak("Welcome to our Pokémon-inspired robot dog performance!")
    walk(controller)
    dance(controller)
    bark(controller)

def talent_show(controller):
    controller.speak("Welcome to the talent show!")
    for name in ("sit", "walk", "dance", "bark", "push-ups", "handshake", "high five", "jump"):
        print(f"\nNext trick: {name}")
        input("Press Enter to continue, or Ctrl+C to stop...")
        TRICKS[name](controller)

def interaction_show(controller):
    controller.speak("You can type a command, or try voice input if a microphone is configured.")
    while True:
        choice = input("Type a command, 'voice', or 'back': ").strip().lower()
        if choice == "back":
            break
        if choice == "voice":
            choice = listen_once() or ""
            print(f"Recognized: {choice}")
        if choice in TRICKS:
            TRICKS[choice](controller)
        elif "joke" in choice:
            controller.speak("Why did the robot dog sit down? Because it needed to recharge its paws!")
        elif "purpose" in choice or "who are you" in choice:
            show_intro(controller)
        else:
            controller.speak("I did not understand that command. Please try again.")

def music_show(controller):
    tracks = list_tracks()
    if not tracks:
        print("No music found. Add MP3, WAV, or OGG files to assets/music.")
        return
    for i, track in enumerate(tracks, 1):
        print(f"{i}. {track.name}")
    try:
        selected = int(input("Choose a track number: ")) - 1
        track = tracks[selected]
    except (ValueError, IndexError):
        print("That selection was not valid.")
        return
    play_track(track)
    dance(controller)

def menu(controller):
    levels = {
        "1": ("Meet PiDog", show_intro),
        "2": ("Christmas Show", christmas_show),
        "3": ("Pokémon Show", pokemon_show),
        "4": ("Human Interaction", interaction_show),
        "5": ("Talent Show", talent_show),
        "6": ("Music and Dance", music_show),
        "7": ("Rescue Assistant Concept", explain_rescue_purpose),
        "8": ("Finale", lambda c: (c.speak("Thank you for watching our PiDog show!"), dance(c), sit(c))),
    }
    while True:
        print("\n========== PiDog AI ROBOTICS SHOW ==========")
        for key, (label, _) in levels.items():
            print(f"{key}. {label}")
        print("0. Exit")
        choice = input("Choose a level: ").strip()
        if choice == "0":
            break
        item = levels.get(choice)
        if item:
            try:
                item[1](controller)
            except KeyboardInterrupt:
                print("\nPerformance stopped.")
        else:
            print("Please choose a number from 0 to 8.")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--demo", action="store_true",
                        help="run without connecting to PiDog hardware")
    args = parser.parse_args()
    controller = PiDogController(demo=args.demo)
    try:
        menu(controller)
    finally:
        controller.close()

if __name__ == "__main__":
    main()
