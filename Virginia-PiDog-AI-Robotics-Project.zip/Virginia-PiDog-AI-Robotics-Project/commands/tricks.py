"""PiDog talent-show routines.

Action names are examples commonly used in PiDog demonstrations. Confirm support
and parameters in the version installed on your Raspberry Pi.
"""

def sit(controller):
    controller.action("sit")

def walk(controller):
    controller.action("forward", step_count=3)

def dance(controller):
    controller.action("dance")

def play_dead(controller):
    controller.action("lie")

def jump(controller):
    controller.action("jump")

def pushups(controller):
    controller.action("push_up")

def bark(controller):
    controller.action("bark")

def howl(controller):
    controller.action("howling")

def handshake(controller):
    controller.action("handshake")

def high_five(controller):
    controller.action("high_five")

TRICKS = {
    "sit": sit,
    "walk": walk,
    "dance": dance,
    "play dead": play_dead,
    "jump": jump,
    "push-ups": pushups,
    "bark": bark,
    "howl": howl,
    "handshake": handshake,
    "high five": high_five,
}
