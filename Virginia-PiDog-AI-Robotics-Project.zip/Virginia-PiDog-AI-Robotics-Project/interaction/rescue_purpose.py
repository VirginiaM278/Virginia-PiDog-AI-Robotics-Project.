"""Educational explanation of the project's rescue-assistance concept."""

RESCUE_MESSAGE = (
    "I am PiDog, an educational robot dog. A robot like me could support "
    "trained search-and-rescue teams by carrying sensors, communicating, "
    "and helping signal a location. This class project is a demonstration "
    "and does not independently find or rescue people."
)

def explain_rescue_purpose(controller):
    controller.speak(RESCUE_MESSAGE)
