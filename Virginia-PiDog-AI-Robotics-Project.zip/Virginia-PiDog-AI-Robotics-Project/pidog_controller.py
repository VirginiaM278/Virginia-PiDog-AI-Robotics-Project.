"""Small hardware wrapper for SunFounder PiDog, with a safe demo mode."""
from __future__ import annotations

class PiDogController:
    def __init__(self, demo: bool = False):
        self.demo = demo
        self.dog = None
        if not demo:
            try:
                from pidog import Pidog
                self.dog = Pidog()
            except Exception as exc:
                raise RuntimeError(
                    "Could not initialize PiDog. Check the PiDog/Robot HAT installation "
                    "and hardware connection, or run with --demo."
                ) from exc

    def action(self, action_name: str, **kwargs):
        """Run a PiDog action. Verify action names for your installed library version."""
        if self.demo:
            print(f"[DEMO] PiDog action: {action_name} {kwargs}")
            return
        if self.dog is None:
            raise RuntimeError("PiDog is not initialized.")
        try:
            self.dog.do_action(action_name, **kwargs)
        except Exception as exc:
            print(f"Action '{action_name}' was not available or failed: {exc}")
            print("Check the action name and parameters in your installed PiDog documentation.")

    def speak(self, words: str):
        if self.demo:
            print(f"[DEMO SPEECH] {words}")
            return
        if self.dog is not None and hasattr(self.dog, "speak"):
            try:
                self.dog.speak(words)
                return
            except Exception as exc:
                print(f"PiDog speech unavailable: {exc}")
        print(words)

    def close(self):
        if self.dog is not None:
            try:
                self.dog.close()
            except Exception:
                pass
