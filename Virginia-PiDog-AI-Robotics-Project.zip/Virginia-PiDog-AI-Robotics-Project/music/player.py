"""Optional local music playback from assets/music/."""

from pathlib import Path

MUSIC_DIR = Path(__file__).resolve().parents[1] / "assets" / "music"

def list_tracks():
    MUSIC_DIR.mkdir(parents=True, exist_ok=True)
    return sorted(p for p in MUSIC_DIR.iterdir()
                  if p.suffix.lower() in {".mp3", ".wav", ".ogg"})

def play_track(track):
    try:
        import pygame
        pygame.mixer.init()
        pygame.mixer.music.load(str(track))
        pygame.mixer.music.play()
        print(f"Playing: {track.name}")
        input("Press Enter to stop the music...")
        pygame.mixer.music.stop()
        pygame.mixer.quit()
    except ImportError:
        print("Install pygame to enable music playback: python3 -m pip install pygame")
    except Exception as exc:
        print(f"Could not play {track.name}: {exc}")
